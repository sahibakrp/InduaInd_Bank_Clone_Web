document.addEventListener("DOMContentLoaded", function () {
    const carouselSlide = document.querySelector(".carousel-slide");
    const slides = document.querySelectorAll(".slide");
    const prevButton = document.querySelector(".prev");
    const nextButton = document.querySelector(".next");
  
    let slideIndex = 0;
  
    // Function to move to the next slide
    function nextSlide() {
      slideIndex++;
      if (slideIndex >= slides.length) {
        slideIndex = 0;
      }
      updateSlidePosition();
    }
  
    // Function to move to the previous slide
    function prevSlide() {
      slideIndex--;
      if (slideIndex < 0) {
        slideIndex = slides.length - 1;
      }
      updateSlidePosition();
    }
  
    // Function to update the slide position
    function updateSlidePosition() {
      carouselSlide.style.transform = `translateX(-${slideIndex * 100}%)`;
    }
  
    // Attach event listeners to the control buttons
    nextButton.addEventListener("click", nextSlide);
    prevButton.addEventListener("click", prevSlide);
  
    // Automatic sliding every 3 seconds (adjust the timing as needed)
    setInterval(nextSlide, 6000);
  });

  // <!-- ----JAVA Script for toggle menu----- ->
  
   var navlinks = document.getElementById("navlinks");
   function showMenu(){
       navlinks.style.right ="0";
   }
   function hideMenu(){
       navlinks.style.right = "-200px";
   }



//    ------------------popup img-----------------------

document.addEventListener('DOMContentLoaded', function() {
  showPopup(); // Show the popup form when the page loads
});

function showPopup() {
  var popupContainer = document.getElementById('popupContainer');
  popupContainer.style.display = 'block';
}

function closePopup() {
  var popupContainer = document.getElementById('popupContainer');
  popupContainer.style.display = 'none';
}

// Handle form submission (you can add additional login logic here)
document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault();
  var email = document.getElementById('email').value;
  var password = document.getElementById('password').value;
  var rememberMe = document.getElementById('remember').checked;

  // Perform login/authentication logic here
  console.log("Email:", email);
  console.log("Password:", password);

  closePopup();
});






